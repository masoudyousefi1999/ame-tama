// This is a placeholder file that will be replaced by next-pwa
// Do not modify this file directly
