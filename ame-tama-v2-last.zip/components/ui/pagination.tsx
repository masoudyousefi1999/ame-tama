"use client";

import * as React from "react";
import { ChevronLeft, ChevronRight, MoreHorizontal } from "lucide-react";

import { cn } from "@/lib/utils";
import { type ButtonProps, buttonVariants } from "@/components/ui/button";

/**
 * Pagination components — style-token ready
 * ▸ semantic utility classes (`bg-muted`, `text-foreground`, …)
 * ▸ no behavioural changes
 */

const Pagination = ({ className, ...props }: React.ComponentProps<"nav">) => (
  <nav
    role="navigation"
    aria-label="pagination"
    className={cn(
      "mx-auto flex w-full justify-center text-muted-foreground",
      className
    )}
    {...props}
  />
);
Pagination.displayName = "Pagination";

/* ────────────────────────────  CONTENT  ──────────────────────────── */
const PaginationContent = React.forwardRef<
  HTMLUListElement,
  React.ComponentProps<"ul">
>(({ className, ...props }, ref) => (
  <ul
    ref={ref}
    className={cn("flex items-center gap-1", className)}
    {...props}
  />
));
PaginationContent.displayName = "PaginationContent";

/* ─────────────────────────────  ITEM  ───────────────────────────── */
const PaginationItem = React.forwardRef<
  HTMLLIElement,
  React.ComponentProps<"li">
>(({ className, ...props }, ref) => (
  <li ref={ref} className={cn("", className)} {...props} />
));
PaginationItem.displayName = "PaginationItem";

/* ─────────────────────────────  LINK  ───────────────────────────── */
type PaginationLinkProps = {
  isActive?: boolean;
} & Pick<ButtonProps, "size"> &
  React.ComponentProps<"a">;

const PaginationLink = ({
  className,
  isActive,
  size = "icon",
  ...props
}: PaginationLinkProps) => (
  <a
    aria-current={isActive ? "page" : undefined}
    className={cn(
      buttonVariants({
        variant: isActive ? "secondary" : "ghost",
        size,
      }),
      "rounded-full focus-visible:ring-ring",
      className
    )}
    {...props}
  />
);
PaginationLink.displayName = "PaginationLink";

/* ───────────────────────  PREV / NEXT  ─────────────────────── */
const PaginationPrevious = ({
  className,
  ...props
}: React.ComponentProps<typeof PaginationLink>) => (
  <PaginationLink
    aria-label="Go to previous page"
    size="default"
    className={cn("gap-1 rtl:flex-row-reverse px-2", className)}
    {...props}
  >
    <ChevronLeft className="h-4 w-4 shrink-0" />
    <span>Previous</span>
  </PaginationLink>
);
PaginationPrevious.displayName = "PaginationPrevious";

const PaginationNext = ({
  className,
  ...props
}: React.ComponentProps<typeof PaginationLink>) => (
  <PaginationLink
    aria-label="Go to next page"
    size="default"
    className={cn("gap-1 rtl:flex-row-reverse px-2", className)}
    {...props}
  >
    <span>Next</span>
    <ChevronRight className="h-4 w-4 shrink-0" />
  </PaginationLink>
);
PaginationNext.displayName = "PaginationNext";

/* ───────────────────────────  ELLIPSIS  ─────────────────────────── */
const PaginationEllipsis = ({
  className,
  ...props
}: React.ComponentProps<"span">) => (
  <span
    aria-hidden
    className={cn(
      "flex h-9 w-9 items-center justify-center rounded-full bg-muted text-muted-foreground",
      className
    )}
    {...props}
  >
    <MoreHorizontal className="h-4 w-4" />
    <span className="sr-only">More pages</span>
  </span>
);
PaginationEllipsis.displayName = "PaginationEllipsis";

export {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationPrevious,
  PaginationNext,
  PaginationEllipsis,
};
