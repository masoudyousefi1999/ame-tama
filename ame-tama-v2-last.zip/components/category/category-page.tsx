"use client";

import { useState, useEffect } from "react";
import { useRouter, usePathname, useSearchParams } from "next/navigation";
import { Filter, SlidersHorizontal, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import CategoryFilters from "@/components/category/category-filters";
import CategoryProducts from "@/components/category/category-products";
import { type ICategoryType } from "@/lib/categories";
import { Breadcrumb } from "@/components/ui/breadcrumb";
import { cn } from "@/lib/utils";
import Link from "next/link";
import { IProductType } from "@/lib/products";
import Image from "next/image";

interface CategoryPageProps {
  category: ICategoryType & { image: string };
  subcategories?: ICategoryType[];
  sort: string;
  filter?: string;
  page: number;
  products: IProductType[];
}

export default function CategoryPage({
  category,
  subcategories = [],
  sort,
  filter,
  page,
  products,
}: CategoryPageProps) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 500]);
  const [selectedFilters, setSelectedFilters] = useState<string[]>(
    filter ? filter.split(",") : []
  );
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  // sync URL params with state
  useEffect(() => {
    const params = new URLSearchParams(searchParams.toString());

    sort !== "newest" ? params.set("sort", sort) : params.delete("sort");
    selectedFilters.length
      ? params.set("filter", selectedFilters.join(","))
      : params.delete("filter");
    page > 1 ? params.set("page", page.toString()) : params.delete("page");

    const newUrl = params.toString()
      ? `${pathname}?${params.toString()}`
      : pathname;
    router.replace(newUrl, { scroll: false });
  }, [sort, selectedFilters, page, pathname, router, searchParams]);

  const handlePriceRangeChange = (range: [number, number]) => {
    setPriceRange(range);
  };

  const handleFilterChange = (filters: string[]) => {
    setSelectedFilters(filters);
  };

  const handleSortChange = (newSort: string) => {
    const params = new URLSearchParams(searchParams.toString());
    newSort !== "newest" ? params.set("sort", newSort) : params.delete("sort");
    const newUrl = params.toString()
      ? `${pathname}?${params.toString()}`
      : pathname;
    router.replace(newUrl);
  };

  return (
    <div className="container mx-auto mt-16 px-4 py-8 md:mt-24">
      {/* breadcrumb */}
      <Breadcrumb
        items={
          category.name === "figures"
            ? [{ label: "اکشن فیگور", href: `/category/`, isCurrent: true }]
            : [
                { label: "اکشن فیگور", href: `/category/figures` },
                {
                  label: category.name,
                  href: `/category/figures/${category.slug}`,
                  isCurrent: true,
                },
              ]
        }
        className="mb-4"
      />

      {/* hero header */}
      <div className="relative mb-8 h-64 w-full overflow-hidden rounded-lg">
        <Image
          src={category.image || "/placeholder.jpg"}
          alt={category.name}
          fill
          sizes="100vw"
          priority
          style={{ objectFit: "contain" }}
        />
        <h1 className="absolute bottom-4 left-4 font-vazirmatn text-3xl font-extrabold text-foreground drop-shadow-lg">
          {category?.name === "figures" ? "فیگور ها" : category.name}
        </h1>
      </div>

      {/* sub-categories */}
      {subcategories.length > 0 && (
        <section className="mb-14">
          <div className="mb-5 flex items-center justify-between">
            <h2 className="bg-gradient-to-r from-primary to-primary/80 bg-clip-text text-2xl font-extrabold text-transparent font-vazirmatn tracking-tight">
              زیردسته‌های&nbsp;{category.name}
            </h2>
            <span className="text-xs font-vazirmatn text-muted-foreground lg:hidden">
              ← پیمایش افقی →
            </span>
          </div>
          <div className="scrollbar-thin scrollbar-thumb-border dark:scrollbar-thumb-border flex gap-4 overflow-x-auto pb-2 snap-x snap-mandatory md:grid md:grid-cols-3 md:gap-8 md:overflow-visible lg:grid-cols-4 xl:grid-cols-5">
            {subcategories.map((subcat) => (
              <Link
                key={subcat.id}
                href={`/category/figures/${subcat.slug}`}
                className="group relative aspect-square w-32 flex-none snap-start overflow-hidden rounded-3xl transition-transform duration-300 hover:-rotate-x-2 hover:rotate-y-2 sm:w-36 md:w-full"
              >
                <div className="absolute inset-0 rounded-3xl bg-card/30 backdrop-blur-xl shadow-xl ring-1 ring-border transition-all duration-300 group-hover:shadow-2xl" />
                <Image
                  src={subcat.image ?? "/placeholder.jpg"}
                  alt={subcat.name}
                  fill
                  sizes="(max-width:640px) 8rem, (max-width:768px) 9rem, 18vw"
                  className="object-cover transition-transform duration-300 group-hover:scale-105 group-hover:rotate-1"
                />
                <div className="absolute inset-0 rounded-3xl bg-gradient-to-t from-background/70 via-background/30 to-transparent" />
                <div className="absolute inset-0 flex items-end justify-center pb-4">
                  <span className="font-vazirmatn text-xs font-semibold tracking-wide text-primary-foreground sm:text-sm md:text-base drop-shadow-lg">
                    {subcat.name}
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      <div className="flex flex-col gap-8 lg:flex-row">
        {/* desktop filters */}
        <div className="hidden w-64 flex-shrink-0 lg:block">
          <CategoryFilters
            priceRange={priceRange}
            onPriceRangeChange={handlePriceRangeChange}
            selectedFilters={selectedFilters}
            onFilterChange={handleFilterChange}
            category={category}
          />
        </div>

        {/* mobile filter & sort */}
        <div className="mb-4 flex items-center justify-between lg:hidden">
          <Sheet open={isFilterOpen} onOpenChange={setIsFilterOpen}>
            <SheetTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="flex items-center gap-2"
              >
                <Filter className="h-4 w-4" />
                <span className="font-vazirmatn">فیلترها</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] p-0 sm:w-[400px]">
              <div className="h-full overflow-y-auto p-6">
                <div className="mb-6 flex items-center justify-between">
                  <h3 className="font-vazirmatn text-lg font-medium">
                    فیلترها
                  </h3>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setIsFilterOpen(false)}
                    className="h-8 w-8 rounded-full"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <CategoryFilters
                  priceRange={priceRange}
                  onPriceRangeChange={handlePriceRangeChange}
                  selectedFilters={selectedFilters}
                  onFilterChange={handleFilterChange}
                  category={category}
                  onClose={() => setIsFilterOpen(false)}
                />
              </div>
            </SheetContent>
          </Sheet>

          <div className="flex items-center gap-2">
            <SlidersHorizontal className="h-4 w-4 text-muted-foreground" />
            <select
              value={sort}
              onChange={(e) => handleSortChange(e.target.value)}
              className="text-sm font-vazirmatn text-foreground bg-transparent border-none focus:ring-0"
            >
              <option value="newest">جدیدترین</option>
              <option value="price-asc">قیمت: کم به زیاد</option>
              <option value="price-desc">قیمت: زیاد به کم</option>
              <option value="popular">محبوب‌ترین</option>
            </select>
          </div>
        </div>

        {/* products */}
        <div className="flex-1">
          <div className="mb-6 hidden justify-end lg:flex">
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground font-vazirmatn">
                مرتب‌سازی:
              </span>
              <select
                value={sort}
                onChange={(e) => handleSortChange(e.target.value)}
                className="text-sm font-vazirmatn text-foreground bg-transparent border-none focus:ring-0"
              >
                <option value="newest">جدیدترین</option>
                <option value="price-asc">قیمت: کم به زیاد</option>
                <option value="price-desc">قیمت: زیاد به کم</option>
                <option value="popular">محبوب‌ترین</option>
              </select>
            </div>
          </div>

          <CategoryProducts products={products} viewMode="grid" />
        </div>
      </div>
    </div>
  );
}
