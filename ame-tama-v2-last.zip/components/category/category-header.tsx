import Image from "next/image";
import { cn } from "@/lib/utils";
import type { ICategoryType } from "@/lib/categories";

interface CategoryHeaderProps {
  category: ICategoryType;
}

export default function CategoryHeader({ category }: CategoryHeaderProps) {
  const isRoot = category.name === "figures";
  return (
    <header
      className={cn(
        "relative mb-10 overflow-hidden rounded-3xl group",
        isRoot ? "h-[14rem] md:h-[18rem]" : "h-40 md:h-48"
      )}
    >
      {/* background image */}
      <div className="relative h-64 w-full">
        <Image
          src={category.image || "/placeholder.svg"}
          alt={category.name}
          fill
          priority
          quality={70}
          sizes="(max-width:768px) 100vw, 80vw"
          className="
          object-cover brightness-95 saturate-110
          transition-transform duration-700
          group-hover:scale-105 group-hover:rotate-1
        "
        />
      </div>

      {/* soft gradient for legibility */}
      <div className="absolute inset-0 bg-gradient-to-tr from-background/70 via-background/30 to-transparent" />

      {/* copy */}
      <div className="relative z-10 flex h-full flex-col items-center justify-center px-6 text-center">
        <h1
          className={cn(
            "font-vazirmatn font-extrabold tracking-tight text-primary-foreground drop-shadow-lg",
            isRoot ? "text-4xl md:text-5xl" : "text-3xl md:text-4xl"
          )}
        >
          {category.name}
        </h1>

        {category.description && (
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-primary-foreground/85 md:text-base font-vazirmatn">
            {category.description}
          </p>
        )}
      </div>

      {/* bottom glow */}
      <div
        className="
        pointer-events-none absolute -bottom-12 left-1/2 h-24 w-[120%]
        -translate-x-1/2 bg-primary/20 blur-[60px]
        transition-colors group-hover:bg-primary/30
      "
      />
    </header>
  );
}
